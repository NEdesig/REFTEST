-- REFTEST database starter. Run in Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  last_name text not null default '',
  first_name text not null default '',
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.sections (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.rules (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references public.sections(id) on delete cascade,
  rule_number text not null,
  title text not null,
  description text not null default '',
  sort_order integer not null default 0,
  unique(section_id,rule_number)
);
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  rule_id uuid references public.rules(id) on delete set null,
  text text not null,
  pool_type text not null default 'main' check(pool_type in ('main','easy')),
  difficulty text not null default 'normal' check(difficulty in ('easy','normal','hard')),
  time_limit_seconds integer not null default 20 check(time_limit_seconds between 5 and 300),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  option_text text not null,
  is_correct boolean not null default false,
  sort_order integer not null default 0,
  constraint three_options_sort check(sort_order between 0 and 2)
);
create table if not exists public.test_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  test_type text not null check(test_type in ('main','review','easy')),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  score integer,
  total_questions integer not null default 0,
  duration_seconds integer,
  status text not null default 'in_progress' check(status in ('in_progress','completed','abandoned'))
);
create table if not exists public.attempt_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.test_attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id),
  selected_option_id uuid references public.question_options(id),
  is_correct boolean,
  time_spent_seconds integer,
  question_order integer not null,
  unique(attempt_id,question_order)
);
create table if not exists public.question_history (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  attempt_id uuid not null references public.test_attempts(id) on delete cascade,
  shown_at timestamptz not null default now(),
  primary key(user_id,question_id,attempt_id)
);
create table if not exists public.site_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.site_settings(key,value) values('support','{"email":"","phone":"","telegram":"","text":"Если возникла проблема с сайтом, напиши в поддержку."}'::jsonb) on conflict(key) do nothing;

create index if not exists questions_rule_idx on public.questions(rule_id);
create index if not exists questions_pool_idx on public.questions(pool_type,is_active);
create index if not exists attempts_user_date_idx on public.test_attempts(user_id,created_at desc);
create index if not exists answers_attempt_idx on public.attempt_answers(attempt_id);
create index if not exists history_user_date_idx on public.question_history(user_id,shown_at desc);

-- Create profile at signup. Role is always forced to user; never accept role from metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles(id,last_name,first_name,role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'last_name',''),
    coalesce(new.raw_user_meta_data->>'first_name',''),
    'user'
  ) on conflict(id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.sections enable row level security;
alter table public.rules enable row level security;
alter table public.questions enable row level security;
alter table public.question_options enable row level security;
alter table public.test_attempts enable row level security;
alter table public.attempt_answers enable row level security;
alter table public.question_history enable row level security;
alter table public.site_settings enable row level security;

-- Helper checks admin using profile. Users cannot promote themselves.
create or replace function public.is_reftest_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists(select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin');
$$;
revoke all on function public.is_reftest_admin() from public;
grant execute on function public.is_reftest_admin() to authenticated;

-- Public can read the question text and choices, but NOT the correct-answer flags.
-- question_options has no user SELECT policy: frontend must not fetch is_correct directly.
create policy "read sections authenticated" on public.sections for select to authenticated using (true);
create policy "read rules authenticated" on public.rules for select to authenticated using (true);
create policy "read questions authenticated" on public.questions for select to authenticated using (is_active = true or public.is_reftest_admin());
create policy "read own profile" on public.profiles for select to authenticated using (id = (select auth.uid()) or public.is_reftest_admin());
create policy "update own profile names" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()) and role = 'user');
create policy "read own attempts" on public.test_attempts for select to authenticated using (user_id = (select auth.uid()) or public.is_reftest_admin());
create policy "read own answers" on public.attempt_answers for select to authenticated using (exists(select 1 from public.test_attempts a where a.id = attempt_id and (a.user_id = (select auth.uid()) or public.is_reftest_admin())));
create policy "read own history" on public.question_history for select to authenticated using (user_id = (select auth.uid()) or public.is_reftest_admin());
create policy "read support settings" on public.site_settings for select to authenticated using (key = 'support');

-- Admin-only authoring policies
create policy "admin manage sections" on public.sections for all to authenticated using (public.is_reftest_admin()) with check (public.is_reftest_admin());
create policy "admin manage rules" on public.rules for all to authenticated using (public.is_reftest_admin()) with check (public.is_reftest_admin());
create policy "admin manage questions" on public.questions for all to authenticated using (public.is_reftest_admin()) with check (public.is_reftest_admin());
create policy "admin manage options" on public.question_options for all to authenticated using (public.is_reftest_admin()) with check (public.is_reftest_admin());
create policy "admin manage settings" on public.site_settings for all to authenticated using (public.is_reftest_admin()) with check (public.is_reftest_admin());
create policy "admin read all profiles" on public.profiles for select to authenticated using (public.is_reftest_admin());

-- SECURITY NOTE:
-- This starter schema intentionally does not let the browser read correct-answer flags or write
-- attempts/answers. Before enabling real scored tests, implement a server-side Edge Function/RPC
-- that chooses questions, checks answers, enforces cooldowns and records attempts. Do not add
-- broad SELECT/INSERT policies to question_options or attempts.
-- Frontend demo mode works without a Supabase project. See README for current limitations.